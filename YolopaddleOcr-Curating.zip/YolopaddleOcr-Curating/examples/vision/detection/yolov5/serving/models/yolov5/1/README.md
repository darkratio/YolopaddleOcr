# YOLOV5 Pipeline

The pipeline directory does not have model files, but a version number directory needs to be maintained.
