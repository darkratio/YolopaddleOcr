# 如何添加一个模型

本文档以[yolov5](https://github.com/ultralytics/yolov5)为例，说明如何添加新的模型支持。
