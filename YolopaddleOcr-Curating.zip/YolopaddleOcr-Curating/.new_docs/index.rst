FastDeploy
=======================================

* GitHub Repository:  https://github.com/PaddlePaddle/FastDeploy

* Issue Feedback: http://www.github.com/PaddlePaddle/FastDeploy/issues

* Contact Us: fastdeploy@baidu.com

..  toctree::
    :caption: 文档目录
    :maxdepth: 2
    :titlesonly:

    build_and_install/index
    quick_start/index
