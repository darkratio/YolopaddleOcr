# Object Detection API Reference

## fastdeploy.vision.detection.PPYOLOE

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PPYOLOE
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.PPYOLO

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PPYOLO
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.PPYOLOv2

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PPYOLOv2
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.PicoDet

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PicoDet
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.PaddleYOLOX

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PaddleYOLOX
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.YOLOv3

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.PaddleYOLOX
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.FasterRCNN

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.FasterRCNN
    :members:
    :inherited-members:
```

## fastdeploy.vision.detection.MaskRCNN

```{eval-rst}
.. autoclass:: fastdeploy.vision.detection.MaskRCNN
    :members:
    :inherited-members:
```
