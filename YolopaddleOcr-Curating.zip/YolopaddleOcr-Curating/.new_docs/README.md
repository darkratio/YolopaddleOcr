# 使用文档

FastDeploy在Readthedocs托管在线文档，[点击](https://fastdeploy.readthedocs.io/en/latest/)访问。

## 构建本地文档

```
pip install -r requirements.txt
make html
```

浏览器打开`_build/html/index.html`即可阅读本地编译后的文档
