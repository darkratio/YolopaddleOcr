编译与安装
=======================================

FastDeploy支持在多种平台与硬件的部署，提供预编译库，同时也支持开发者根据需求灵活编译

..  toctree::
    :caption: 编译与安装
    :maxdepth: 2
    :titlesonly:
    
    cpu.md
    gpu.md
    jetson.md
